import { useState } from "react";
import { useNavigate } from "react-router";
import logoSrc from "../../imports/runtu_logo.png";

export function Login() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleSubmit = (e: React.FormEvent) => { e.preventDefault(); navigate("/app"); };

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#FAFAFA] font-[Montserrat] px-4">
      <div className="w-full max-w-sm flex flex-col items-center">
        <img src={logoSrc} alt="Runtu" className="w-14 h-14 mb-2" />
        <h1 className="text-2xl text-gray-900 tracking-tight" style={{ fontWeight: 900 }}>Bienvenido de vuelta</h1>
        <p className="text-gray-400 text-sm mt-1">Inicia sesion en Runtu.tech</p>
        <form onSubmit={handleSubmit} className="w-full mt-8 space-y-3">
          <input type="email" placeholder="Email" value={email} onChange={e => setEmail(e.target.value)}
            className="w-full bg-white border border-gray-200 rounded-xl px-4 py-3 text-gray-900 placeholder-gray-400 focus:border-gray-400 focus:ring-2 focus:ring-gray-200 outline-none transition-all text-sm" />
          <input type="password" placeholder="Contrasena" value={password} onChange={e => setPassword(e.target.value)}
            className="w-full bg-white border border-gray-200 rounded-xl px-4 py-3 text-gray-900 placeholder-gray-400 focus:border-gray-400 focus:ring-2 focus:ring-gray-200 outline-none transition-all text-sm" />
          <button type="submit" className="w-full bg-gray-900 hover:bg-gray-800 text-white rounded-xl px-8 py-3.5 transition-all hover:shadow-lg" style={{ fontWeight: 700 }}>
            Iniciar sesion
          </button>
        </form>
        <p className="text-gray-400 mt-6 text-sm">
          No tienes cuenta? <button onClick={() => navigate("/register")} className="text-gray-900 hover:underline" style={{ fontWeight: 600 }}>Registrate</button>
        </p>
      </div>
    </div>
  );
}
